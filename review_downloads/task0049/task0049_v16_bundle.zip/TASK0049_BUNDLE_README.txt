EXPERIMENTAL — HUMAN VALIDATION REQUIRED
Derived v1.6 outputs and changed implementation/docs only; no raw export or prior frozen datasets.
Reproduction requires the existing KSHE_alert_test workspace with frozen inputs/profiles.
Run python -m kyiv_alerts.classification_v16 --root . then python scripts/validate_v16.py --root .
No Git commit/push or forecasting has been performed.
